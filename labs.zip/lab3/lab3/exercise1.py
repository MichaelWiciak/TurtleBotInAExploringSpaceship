import threading
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from rclpy.exceptions import ROSInterruptException
import signal
import math


class FirstWalker(Node):
    def __init__(self):
        super().__init__('firstwalker')
        self.publisher = self.create_publisher(Twist, '/cmd_vel', 10)
        self.rate = self.create_rate(10)  # 10 Hz

    def walk_forward(self):
        desired_velocity = Twist()
        desired_velocity.linear.x = 1.1  # Forward with 0.2 m/s
        
        desired_velocity.angular.z = math.pi/3

        
        for i in range(1):
            self.publisher.publish(desired_velocity)
            self.rate.sleep()
            desired_velocity.angular.z *= i


    def stop(self):
        desired_velocity = Twist()
        self.publisher.publish(desired_velocity)

def main():
    def signal_handler(sig, frame):
        first_walker.stop()
        rclpy.shutdown()

    rclpy.init(args=None)
    first_walker = FirstWalker()

    signal.signal(signal.SIGINT, signal_handler)
    thread = threading.Thread(target=rclpy.spin, args=(first_walker,), daemon=True)
    thread.start()

    try:
        while rclpy.ok():
            first_walker.walk_forward()
    except ROSInterruptException:
        pass


if __name__ == "__main__":
    main()


