import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from std_msgs.msg import Int8


class Talker(Node):
    def __init__(self):
        super().__init__('talker')
        self.publisher = self.create_publisher(String, 'chatter7', 10)
        self.additionalPublisher = self.create_publisher(Int8, 'numeric_chatter7', 10)

        timer_in_seconds = 0.5
        additionalTimer = 0.1
        self.timer = self.create_timer(timer_in_seconds, self.talker_callback)
        self.additionalTimer = self.create_timer(additionalTimer, self.additionalTalker_callback)
        self.counter = 0
        
        self.additionalCounter = 0

    def talker_callback(self):
        msg = String()
        msg.data = f'Hello TIMETABLEX.COM, {self.counter}'
        self.publisher.publish(msg)
        self.get_logger().info(f'Publishing: {msg.data}')
        self.counter += 1
    
    def additionalTalker_callback(self):
        msg = Int8()
        msg.data = self.additionalCounter
        self.additionalPublisher.publish(msg)
        self.get_logger().info(f'Number: {self.additionalCounter}')
        self.additionalCounter += 1
        
        if self.additionalCounter > 127:
            self.additionalCounter=0
            

def main(args=None):
    rclpy.init(args=args)

    talker = Talker()
    rclpy.spin(talker)
    


if __name__ == '__main__':
    main()


