# Exercise 4 - following a colour (green) and stopping upon sight of another (blue).

# from __future__ import division
import threading
import sys, time
import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, Vector3
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from rclpy.exceptions import ROSInterruptException
import signal


class Robot(Node):
    def __init__(self):
        super().__init__("robot")
        self.publisher = self.create_publisher(Twist, "/cmd_vel", 10)
        self.rate = self.create_rate(10)  # 10 Hz

        # Initialise a publisher to publish messages to the robot base
        # We covered which topic receives messages that move the robot in the 3rd Lab Session

        # Initialise any flags that signal a colour has been detected (default to false)
        self.red_detected = False
        self.green_detected = False
        self.blue_detected = False
        self.moveBackwardsFlag = False
        self.moveForwardsFlag = False
        self.stopFlag = False
        # Initialise the value you wish to use for sensitivity in the colour detection (10 should be enough)
        self.sensitivity = 10

        # Initialise some standard movement messages such as a simple move forward and a message with all zeroes (stop)
        self.twist_stop = Twist()
        self.twist_forward = Twist()
        self.twist_forward.linear.x = 0.5
        self.twist_backward = Twist()
        self.twist_backward.linear.x = -0.5

        # Remember to initialise a CvBridge() and set up a subscriber to the image topic you wish to use
        # We covered which topic to subscribe to should you wish to receive image data
        self.bridge = CvBridge()
        self.subscription = self.create_subscription(
            Image, "/camera/image_raw", self.callback, 10
        )
        self.subscription  # prevent unused variable warning

    def callback(self, data):
        try:
            self.moveBackwardsFlag = False
            self.moveForwardsFlag = False
            self.stopFlag = False

            # Convert the received image into a opencv image
            # But remember that you should always wrap a call to this conversion method in an exception handler
            image = self.bridge.imgmsg_to_cv2(data, "bgr8")

            # Set the upper and lower bounds for the two colours you wish to identify
            # hue value = 0 to 179

            hsv_green_lower = np.array([60 - self.sensitivity, 100, 100])
            hsv_green_upper = np.array([60 + self.sensitivity, 255, 255])
            hsv_red_lower = np.array([0 - self.sensitivity, 100, 100])
            hsv_red_upper = np.array([0 + self.sensitivity, 255, 255])

            # Convert the rgb image into a hsv image
            Hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

            # Filter out everything but a particular colour using the cv2.inRange() method

            green_mask = cv2.inRange(Hsv_image, hsv_green_lower, hsv_green_upper)
            red_mask = cv2.inRange(Hsv_image, hsv_red_lower, hsv_red_upper)

            channels = [
                ("green", green_mask),
                ("red", red_mask),
            ]

            self.green_detected = False
            self.red_detected = False
            for colour_name, mask in channels:
                # Apply the mask to the original image using the cv2.bitwise_and() method
                # As mentioned on the worksheet the best way to do this is to bitwise and an image with itself and pass the mask to the mask parameter
                final = cv2.bitwise_and(image, image, mask=mask)

                # Find the contours that appear within the certain colour mask using the cv2.findContours() method
                # For <mode> use cv2.RETR_LIST for <method> use cv2.CHAIN_APPROX_SIMPLE

                img = cv2.cvtColor(final, cv2.COLOR_BGR2GRAY)

                contours, h = cv2.findContours(
                    img, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE
                )

                if len(contours) > 0:
                    # Loop over the contours
                    # There are a few different methods for identifying which contour is the biggest:
                    # Loop through the list and keep track of which contour is biggest or
                    # Use the max() method to find the largest contour
                    c = max(contours, key=cv2.contourArea)

                    # Moments can calculate the center of the contour
                    M = cv2.moments(c)
                    cx, cy = int(M["m10"] / M["m00"]), int(M["m01"] / M["m00"])

                    # Check if the area of the shape you want is big enough to be considered
                    # If it is then change the flag for that colour to be True(1)
                    if (
                        cv2.contourArea(c) > 60
                    ):  # <What do you think is a suitable area?>
                        match colour_name:
                            # Then alter the values of any flags
                            case "green":
                                self.green_detected = True
                            case "red":
                                self.red_detected = True

                        center_x = cx
                        center_y = cy
                        # draw a circle on the contour you're identifying
                        # minEnclosingCircle can find the centre and radius of the largest contour(result from max())
                        (x, y), radius = cv2.minEnclosingCircle(c)
                        colour = (255, 0, 0)
                        thickness = 5
                        cv2.circle(
                            image, (center_x, center_y), int(radius), colour, thickness
                        )

                    # Check if a flag has been set = colour object detected - follow the colour object
                    area = cv2.contourArea(c)
                    print(f"{area=}")
                    if self.green_detected:
                        if area > 20000:
                            # Too close to object, need to move backwards
                            # Set a flag to tell the robot to move backwards when in the main loop
                            self.moveBackwardsFlag = True

                        elif area < 5000:
                            # Too far away from object, need to move forwards
                            # Set a flag to tell the robot to move forwards when in the main loop
                            self.moveForwardsFlag = True

                        # Be sure to do this for the other colour as well
                        # Setting the flag to detect blue, and stop the turtlebot from moving if blue is detected

                    if self.red_detected:
                        self.stopFlag = True

            if self.stopFlag:
                self.moveBackwardsFlag = False
                self.moveForwardsFlag = False

            print("forward", self.moveForwardsFlag)
            print("backwawrd", self.moveBackwardsFlag)
            print("stop", self.stopFlag)

            # Show the resultant images you have created. You can show all of them or just the end result if you wish to.
            cv2.namedWindow("camera_Feed", cv2.WINDOW_NORMAL)
            cv2.imshow("camera_Feed", image)
            cv2.resizeWindow("camera_Feed", 320, 240)
            cv2.waitKey(3)
        except:
            pass

    def walk_forward(self):
        # Use what you learnt in lab 3 to make the robot move forwards
        for _ in range(30):  # Stop for a brief moment
            self.publisher.publish(self.twist_forward)
            self.rate.sleep()

    def walk_backward(self):
        # Use what you learnt in lab 3 to make the robot move backwards

        for _ in range(30):  # Stop for a brief moment
            self.publisher.publish(self.twist_backward)
            self.rate.sleep()

    def stop(self):
        # Use what you learnt in lab 3 to make the robot stop

        self.publisher.publish(self.twist_stop)


# Create a node of your class in the main and ensure it stays up and running
# handling exceptions and such
def main():
    def signal_handler(sig, frame):
        robot.stop()
        rclpy.shutdown()

    # Instantiate your class
    # And rclpy.init the entire node
    rclpy.init(args=None)
    robot = Robot()

    signal.signal(signal.SIGINT, signal_handler)
    thread = threading.Thread(target=rclpy.spin, args=(robot,), daemon=True)
    thread.start()

    try:
        while rclpy.ok():
            # Publish moves
            if robot.moveBackwardsFlag:
                robot.walk_backward()
            elif robot.moveForwardsFlag:
                robot.walk_forward()
            elif robot.stopFlag:
                robot.stop()
            else:
                robot.stop()

    except ROSInterruptException:
        pass

    # Remember to destroy all image windows before closing node
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
