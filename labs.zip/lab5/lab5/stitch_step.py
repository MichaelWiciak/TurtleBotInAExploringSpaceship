# Part B - Stitching images.

import threading
import sys, time
import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, Vector3
from sensor_msgs.msg import Image
from std_msgs.msg import UInt32
from cv_bridge import CvBridge, CvBridgeError
from rclpy.exceptions import ROSInterruptException
import signal
import math

class imageStitcher(Node):
    def __init__(self):

        super().__init__('imageStitcher')

        # Initialise a publisher to publish messages to the robot base
        # We covered which topic receives messages that move the robot in the 3rd Lab Session

        self.publisher = self.create_publisher(Twist, '/cmd_vel', 10)
        self.rate = self.create_rate(10)  # 10 Hz

        # Remember to initialise a CvBridge() and set up a subscriber to the image topic you wish to use
        self.bridge = CvBridge()
        self.subscription = self.create_subscription(Image, '/camera/image_raw', self.callback, 10)
        self.subscription  # prevent unused variable warning
        
        self.snitch = 0
        self.rotate = 0
        
        self.data1= None
        self.data2 = None

        self.current_angular_velocity = 0
        
        self.key=None
        self.image = None
        self.images = []
        self.rotating = False

    def callback(self, data):
        try:
           
            image = self.bridge.imgmsg_to_cv2(data, "bgr8")
            cv2.namedWindow("camera_Feed", cv2.WINDOW_NORMAL)
            cv2.imshow("camera_Feed", image)
            cv2.resizeWindow("camera_Feed", 320, 240)
            self.image = image
            key = cv2.waitKey(3)
            self.key = key
        except:
            pass
        
    def rotate_robot(self):

        # Initialize unused components of desired velocity to zero
        desired_velocity = Twist()
        desired_velocity.linear.x = 0.
        desired_velocity.linear.y = 0.
        desired_velocity.linear.z = 0.
        desired_velocity.angular.x = 0.
        desired_velocity.angular.y = 0.
        
        target = 20 * math.pi / 180
        self.angle_r = target

        self.current_angular_velocity = 0.1
        # Set desired angle in radians
        desired_velocity.angular.z = -self.current_angular_velocity

        # store current time: t0
        t0, _ = self.get_clock().now().seconds_nanoseconds()

        current_angle = 0

        # loop to publish the velocity estimate until desired angle achieved
        # current angle = current angular velocity * (t1 - t0)
        while (current_angle < self.angle_r):
            # Publish the velocity
            self.publisher.publish(desired_velocity)

            # t1 is the current time
            t1, _ = self.get_clock().now().seconds_nanoseconds()  # to_msg()

            # Calculate current angle
            current_angle = self.current_angular_velocity * (t1 - t0)

            self.rate.sleep()

        # set velocity to zero to stop the robot
        self.rotating = False
        self.stop()

    def show_image(self, name, image):
        cv2.namedWindow(name, cv2.WINDOW_NORMAL)
        cv2.imshow(name, image)
        cv2.resizeWindow(name, 320, 240)

    def performStitch(self):
        print("Stitching image")
        # Initialize the SIFT feature detector and extractor

        # image1, image2 = self.images
        image1 = self.images[0]
        image2 = self.images[1]

        sift = cv2.SIFT_create()

        # Detect keypoints and compute descriptors for both images

        print("detecting key points")
        keypoints1, descriptors1 = sift.detectAndCompute(image1, None)
        keypoints2, descriptors2 = sift.detectAndCompute(image2, None)

        # Draw keypoints on the images

        print("drawing key points")
        image1_keypoints = cv2.drawKeypoints(image1, keypoints1, None)
        image2_keypoints = cv2.drawKeypoints(image2, keypoints2, None)

        # Display the images with keypoints

        print("showing images")
        self.show_image("Image 1", image1)
        self.show_image("Image 2", image2)
        self.show_image("Image 1 with Keypoints", image1_keypoints)
        self.show_image("Image 2 with Keypoints", image2_keypoints)
        cv2.waitKey(0)

        # Initialize the feature matcher using brute-force matching
        bf = cv2.BFMatcher(cv2.NORM_L2, crossCheck=True)

        print("matching descriptors")
        # Match the descriptors using brute-force matching
        matches_bf = bf.match(descriptors1, descriptors2)  # Draw the top N matches

        # Sort the matches by distance (lower is better)

        matches_bf = sorted(matches_bf, key=lambda x: x.distance)

        # Draw the top N matches
        num_matches = 50
        print("drawing matching")
        image_matches_bf = cv2.drawMatches(
            image1, keypoints1, image2, keypoints2, matches_bf[:num_matches], None
        )

        # Display the images with matches

        print("showing image")
        self.show_image("Brute-Force Matching", image_matches_bf)

        # Estimate the homography matrix using RANSAC
        # First we need to convert the matched keypoints into a format that that can be used by findHomography

        tp = []  # target points

        qp = []  # query points

        for m in matches_bf:
            tp.append(keypoints2[m.trainIdx].pt)
            qp.append(keypoints1[m.queryIdx].pt)

        tp, qp = np.float32((tp, qp))

        # src_points = np.float32(
        #     [keypoints1[m.queryIdx].pt for m in matches_bf]
        # ).reshape(-1, 1, 2)
        print("finding homography")
        homography, _ = cv2.findHomography(tp, qp, cv2.RANSAC, 5.0)

        # Print the estimated homography matrix

        print("Estimated Homography Matrix:")

        print(homography)

        # Warp the second image using the homography

        # We make the resulting image slightly wider to accommodate the new rotated image

        print("warping perspective")
        result = cv2.warpPerspective(
            image2, homography, (image1.shape[1] + 800, image1.shape[0])
        )

        # I bumped the final image size so I can see the whole paraonoma

        # Blending the warped image with the first image using alpha blending

        # First create a new image large enough to accommodate the stitched images

        print("generating image")
        padded_left_img = cv2.copyMakeBorder(
            image1,
            0,
            0,
            0,
            result.shape[1] - image1.shape[1],
            cv2.BORDER_CONSTANT,
        )

        alpha = 0.5  # blending factor

        blended_image = cv2.addWeighted(padded_left_img, alpha, result, 1 - alpha, 0)

        # Display the blended image

        cv2.namedWindow("Blended Image", cv2.WINDOW_NORMAL)
        cv2.imshow("Blended Image", blended_image)
        cv2.resizeWindow("Blended Image", 1280, 960)

        cv2.waitKey(0)
        print("done")
        return


    def stop(self):
        desired_velocity = Twist()
        desired_velocity.linear.x = 0.0  # Send zero velocity to stop the robot
        self.publisher.publish(desired_velocity)

        

# Create a node of your class in the main and ensure it stays up and running
# handling exceptions and such
def main():

    
    def signal_handler(sig, frame):
        stitcher.stop()
        rclpy.shutdown()

    # Instantiate your class
    # and rclpy.init the entire node
    
    rclpy.init(args=None)
    stitcher = imageStitcher()
    
    signal.signal(signal.SIGINT, signal_handler)
    thread = threading.Thread(target=rclpy.spin, args=(stitcher,), daemon=True)
    thread.start()
    
    first_image_captured = False
    second_image_captured = False
    rotated = False
    stitched = False


    try:
        while rclpy.ok():

            # check if a key has been pressed and store the current image
            if stitcher.key == ord("t"):
                if stitcher.image is not None:
                    if first_image_captured and rotated:
                        pass
                    else:
                        if not first_image_captured:
                            print("Capturing first image")
                            stitcher.images.append(stitcher.image)
                            first_image_captured = True

                # When you have an image rotate the robot
                if first_image_captured and not rotated:
                    stitcher.rotate_robot()
                    rotated = True
            if first_image_captured and rotated and not stitcher.rotating and not second_image_captured:
                print("Capturing second image")
                stitcher.images.append(stitcher.image)
                second_image_captured = True

            if first_image_captured and second_image_captured:
                if not stitched:
                    stitcher.performStitch()
                    stitched = True
            # Once you have both images we can try to stitch them together
            # but make sure you don't capture any more images
            # stitcher.performStitch()
            pass


    except ROSInterruptException:
            pass

    # Remember to destroy all image windows before closing node
    cv2.destroyAllWindows()

# Check if the node is executing in the main path
if __name__ == '__main__':
    main()
