# Exercise 3 - If green object is detected, and above a certain size, then send a message (print or use lab2)

import threading
import sys, time
import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, Vector3
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from rclpy.exceptions import ROSInterruptException
import signal



class colourIdentifier(Node):
    def __init__(self):
        super().__init__('cI')
        # Initialise any flags that signal a colour has been detected (default to false)
        self.red_detected = False
        self.blue_detected = False
        self.green_detected = False
        # Initialise the value you wish to use for sensitivity in the colour detection (10 should be enough)
        self.sensitivity = 10

        # Remember to initialise a CvBridge() and set up a subscriber to the image topic you wish to use
        # We covered which topic to subscribe to should you wish to receive image data
        self.bridge = CvBridge()
        self.subscription = self.create_subscription(Image, '/camera/image_raw', self.callback, 10)
        self.subscription  # prevent unused variable warning
        
        
        



    def callback(self, data):


        # Convert the received image into a opencv image
        image = self.bridge.imgmsg_to_cv2(data, 'bgr8')
        


        hsv_green_lower = np.array([60 - self.sensitivity, 100, 100])
        hsv_green_upper = np.array([60 + self.sensitivity, 255, 255])
        
        hsv_red_lower = np.array([0 - self.sensitivity, 100, 100])
        hsv_red_upper = np.array([0 + self.sensitivity, 255, 255])
    
        hsv_blue_lower = np.array([120 - self.sensitivity, 100, 100])
        hsv_blue_upper = np.array([120 + self.sensitivity, 255, 255])

        # Convert the rgb image into a hsv image
        Hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        
        mask_green = cv2.inRange(Hsv_image, hsv_green_lower, hsv_green_upper) 
        result_green_image = cv2.bitwise_and(image, image, mask=mask_green)
        
        
        mask_red = cv2.inRange(Hsv_image, hsv_red_lower, hsv_red_upper) 
        result_red_image = cv2.bitwise_and(image, image, mask=mask_red)
        
        
        mask_blue = cv2.inRange(Hsv_image, hsv_blue_lower, hsv_blue_upper) 
        result_blue_image = cv2.bitwise_and(image, image, mask=mask_blue)
        
        # Filter out everything but particular colours using the cv2.inRange() method
        # Do this for each colour
        
        result_green_gray = cv2.cvtColor(result_green_image, cv2.COLOR_BGR2GRAY)
        result_red_gray = cv2.cvtColor(result_red_image, cv2.COLOR_BGR2GRAY)
        result_blue_gray = cv2.cvtColor(result_blue_image, cv2.COLOR_BGR2GRAY)

        # Find the contours that appear within the certain colour mask using the cv2.findContours() method
        contours_green, hierarchy = cv2.findContours(result_green_gray, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        contours_red, hierarchy = cv2.findContours(result_red_gray, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        contours_blue, hierarchy = cv2.findContours(result_blue_gray, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        # For <mode> use cv2.RETR_LIST for <method> use cv2.CHAIN_APPROX_SIMPLE

        if len(contours_green) > 0:
            c = max(contours_green, key=cv2.contourArea)

            M = cv2.moments(c)
            cx, cy = int(M['m10']/M['m00']), int(M['m01']/M['m00'])
            if cv2.contourArea(c) > 5: #<What do you think is a suitable area?>
                (x, y), radius = cv2.minEnclosingCircle(c)
                center_x = cx
                center_y = cy
                thickness = 5
                colour = (0, 0, 0) 
                cv2.circle(image,(center_x,center_y),int(radius),colour,thickness)
                self.green_detected = True
        if (self.green_detected):
            print("Green Detected")
            self.green_detected = False

        if len(contours_red) > 0:
            c = max(contours_red, key=cv2.contourArea)
            M = cv2.moments(c)
            cx, cy = int(M['m10']/M['m00']), int(M['m01']/M['m00'])
            if cv2.contourArea(c) > 5: #<What do you think is a suitable area?>
                (x, y), radius = cv2.minEnclosingCircle(c)
                center_x = cx
                center_y = cy
                thickness = 5
                colour = (0, 0, 0) 
                cv2.circle(image,(center_x,center_y),int(radius),colour,thickness)
                self.red_detected = True
        if (self.red_detected):
            print("Red Detected")
            self.red_detected = False
            
        
        if len(contours_blue) > 0:
            c = max(contours_blue, key=cv2.contourArea)
            M = cv2.moments(c)
            cx, cy = int(M['m10']/M['m00']), int(M['m01']/M['m00'])
            if cv2.contourArea(c) > 5: #<What do you think is a suitable area?>
                (x, y), radius = cv2.minEnclosingCircle(c)
                center_x = cx
                center_y = cy
                thickness = 5
                colour = (0, 0, 0) 
                cv2.circle(image,(center_x,center_y),int(radius),colour,thickness)
                self.blue_detected = True
        if (self.blue_detected):
            print("Blue Detected")
            self.blue_detected = False


        cv2.namedWindow('camera_Feed3',cv2.WINDOW_NORMAL)
        cv2.imshow('camera_Feed3', image)
        cv2.resizeWindow('camera_Feed3',320,240)
        cv2.waitKey(3)


# Create a node of your class in the main and ensure it stays up and running
# handling exceptions and such
def main():
    def signal_handler(sig, frame):
        rclpy.shutdown()

    
    # Instantiate your class
    # And rclpy.init the entire node
    rclpy.init(args=None)
   
    cI = colourIdentifier()

    signal.signal(signal.SIGINT, signal_handler)
    thread = threading.Thread(target=rclpy.spin, args=(cI,), daemon=True)
    thread.start()

    try:
        while rclpy.ok():
            continue
    except ROSInterruptException:
        pass

    # Remember to destroy all image windows before closing node
    cv2.destroyAllWindows()


# Check if the node is executing in the main path
if __name__ == '__main__':
    main()
